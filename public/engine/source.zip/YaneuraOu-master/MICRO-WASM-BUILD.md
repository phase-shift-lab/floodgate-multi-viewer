# Floodgate micro WASM build (2026-10-16)

This is the complete corresponding engine source distributed with the WASM.
Upstream: https://github.com/yaneurao/YaneuraOu
Master checked at build: c1b80eaa09fe13d5f12b1599d1ae4d53c224de30
Toolchain: official Emscripten SDK 4.0.23; GNU make; Python 3.

Local edits already applied in this archive:

- source/engine.cpp: Engine::add_options default Threads 4 -> 1.
- source/Makefile: PTHREAD_POOL_SIZE 32 -> 1.
- source/Makefile: STRICT=1 -> STRICT=0 (retain Module callbacks/options).
- source/Makefile: Closure disabled (no Java tool dependency).

From an emsdk environment with GNU make and Python in PATH:

```sh
cd source
make -j1 normal COMPILER=em++ PYTHON=python YANEURAOU_EDITION=YANEURAOU_ENGINE_SFNN_ka2_2048_8_64_progress8 TARGET_CPU=WASM EVAL_EMBEDDING=OFF
```

Outputs: source/yaneuraou.js and source/yaneuraou.wasm.
The generator creates SFNN_ka2_2048_8_64_progress8.h before compiling.
The application writes nn.bin and progress.bin to /eval in Emscripten FS.
Set EvalDir=/eval, FV_SCALE=24, USI_Hash=16, MultiPV=3, BookFile=no_book.
Threads defaults to 1 in this build. Do not send a redundant Threads=1 command:
resizing the same thread pool synchronously can stall browser initialization.
Run in a dedicated Worker on a cross-origin-isolated page.
Evaluation files are separately distributed under MIT and are not in this source archive.

The build used Windows, MSYS2 GNU make, and the emsdk Python executable plus
upstream/emscripten/em++.py as COMPILER. No native executable is distributed.
